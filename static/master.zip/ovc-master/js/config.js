var facebook_api_key = '';
var ovc_api_url = '';
